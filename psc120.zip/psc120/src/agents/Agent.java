package agents;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.util.Bag;

public class Agent implements Steppable {
	int x;
	int y;
	int dirx;
	int diry;
	

	public Agent(int x, int y, int dirx, int diry) {
		super();
		this.x = x;
		this.y = y;
		this.dirx = dirx;
		this.diry = diry;
	}
	
	public int decideDirx(Environment state, Bag neighbors) {
		   int a=0,b=0,c=0;
		   for(int i=0;i<neighbors.numObjs;i++) {
		   Agent x = (Agent)neighbors.objs[i];
			final int dx = x.dirx;
			if(dx == -1) a++;
			else if(dx == 0)b++;
			else c++;
		    }
		    if(a > b && a > c) {
			return -1; //a
		    }
		    else if(b > a && b > c) {
			return 0;//b
		    }
		    else if (c > a && c > b) {
			return 1; //c
		    }
		    else if (a==b) {
			if(a > c) {
			     if(state.random.nextBoolean(0.5)) {
				return -1; //a
			      }
			     else
			         return 0;//b
				}
			  else {
			    return 0;
		        }
		     }
		     else if (a==c) {
			   if(a > b) {
				if(state.random.nextBoolean(0.5)) {
				  return -1; //a
				}
			        else
				  return 1;//b
			   }
			   else {
				return 0;
			   }
			}
			else if (b==c) {
			    if(b > a) {
			          if(state.random.nextBoolean(0.5)) {
					return 0; //b
					}
				   else
					return 1;//c
				}
				else {
					return 0;
				}
			}
			else {
				return state.random.nextInt(3)-1;
			}
		}


	      public int decideDiry(Environment state, Bag neighbors) {
		   int a=0,b=0,c=0;
		   for(int i=0;i<neighbors.numObjs;i++) {
		   Agent x = (Agent)neighbors.objs[i];
			final int dy = x.diry;
			if(dy == -1) a++;
			else if(dy == 0)b++;
			else c++;
		    }
		    if(a > b && a > c) {
			return -1; //a
		    }
		    else if(b > a && b > c) {
			return 0;//b
		    }
		    else if (c > a && c > b) {
			return 1; //c
		    }
		    else if (a==b) {
			if(a > c) {
			     if(state.random.nextBoolean(0.5)) {
				return -1; //a
			      }
			     else
			         return 0;//b
				}
			  else {
			    return 0;
		        }
		     }
		     else if (a==c) {
			   if(a > b) {
				if(state.random.nextBoolean(0.5)) {
				  return -1; //a
				}
			        else
				  return 1;//b
			   }
			   else {
				return 0;
			   }
			}
			else if (b==c) {
			    if(b > a) {
			          if(state.random.nextBoolean(0.5)) {
					return 0; //b
					}
				   else
					return 1;//c
				}
				else {
					return 0;
				}
			}
			else {
				return state.random.nextInt(3)-1;
			}
		}
	      
	
	public int decidedx(Environment state, Bag neighbors) {
		int posx = 0, negx = 0;
		for(int i=0;i<neighbors.numObjs;i++) {
			Agent a = (Agent)neighbors.objs[i];
			if(a.x > this.x)
				posx++;
			if(a.x < this.x)
				negx++;	
		}
		if(posx > negx) {
			return 1;
		}
		if(negx > posx) {
			return -1;
		}
		return state.random.nextInt(3)-1;
		
	}
	
	public int decidedy(Environment state, Bag neighbors) {
		int posy = 0, negy = 0;
		for(int i=0;i<neighbors.numObjs;i++) {
			Agent a = (Agent)neighbors.objs[i];
			if(a.y > this.y)
				posy++;
			if(a.y < this.y)
				negy++;	
		}
		if(posy > negy) {
			return 1;
		}
		if(negy > posy) {
			return -1;
		}
		return state.random.nextInt(3)-1;
		
	}
	
	public void aggregate(Environment state) {
		if(state.random.nextBoolean(state.pa)) {
			Bag neighbors = state.sparseSpace.getMooreNeighbors(x, y, state.searchRadius, state.sparseSpace.TOROIDAL, true);
			dirx = this.decidedx(state, neighbors);
			diry = this.decidedy(state, neighbors);
			placeAgent(state);
		}
		else {
			move(state);
		}

	}
	
	public void flock(Environment state) {
		if(state.random.nextBoolean(state.pf)) {
			Bag neighbors = state.sparseSpace.getMooreNeighbors(x, y, state.searchRadius, state.sparseSpace.TOROIDAL, true);
			dirx = this.decideDirx(state, neighbors);
			diry = this.decideDiry(state, neighbors);
			placeAgent(state);
		}
		else {
			move(state);
		}
	}

	public void move(Environment state) {
		if(state.random.nextBoolean(state.active)) {
			if(state.random.nextBoolean(state.p)) {
				dirx = state.random.nextInt(3)-1;
				diry = state.random.nextInt(3)-1;
			}
			placeAgent(state);
		}
	}
	
	public void placeAgent(Environment state) {
		if(state.oneAgentperCell) {
			int tempx =  state.sparseSpace.stx(x + dirx);
			int tempy = state.sparseSpace.sty(y +diry);
			Bag b = state.sparseSpace.getObjectsAtLocation(tempx, tempy);
			if(b == null) {
				x = tempx;
				y = tempy;
				state.sparseSpace.setObjectLocation(this, x, y);
			}
			
		}
		else {
			x = state.sparseSpace.stx(x + dirx);
			y = state.sparseSpace.sty(y +diry);
			state.sparseSpace.setObjectLocation(this, x, y);
		}
	}


	public void step(SimState state) {
		Environment eState = (Environment)state;
		if(eState.aggregate) {
			aggregate(eState);
		}
		else if(eState.flock) {
			flock(eState);
		}
		else {
			move(eState);
		}

	}

}
