package agents;

import sim.util.Bag;
import spaces.Spaces;
import sweep.SimStateSweep;

public class Environment extends SimStateSweep {
	int n = 100;
	double active = 1.0;
	double p = 0.0;//probability of random movement
	boolean aggregate = false;
	int searchRadius = 2;
	boolean oneAgentperCell = false;
	double pa = 1.0;//the probability of aggregating
	boolean flock = false;
	double pf = 1.0;//the probability of flocking

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	public double getActive() {
		return active;
	}

	public void setActive(double active) {
		this.active = active;
	}

	public double getP() {
		return p;
	}

	public void setP(double p) {
		this.p = p;
	}

	public boolean isAggregate() {
		return aggregate;
	}

	public void setAggregate(boolean aggregate) {
		this.aggregate = aggregate;
	}

	public int getSearchRadius() {
		return searchRadius;
	}

	public void setSearchRadius(int searchRadius) {
		this.searchRadius = searchRadius;
	}

	public boolean isOneAgentperCell() {
		return oneAgentperCell;
	}

	public void setOneAgentperCell(boolean oneAgentperCell) {
		this.oneAgentperCell = oneAgentperCell;
	}

	public double getPa() {
		return pa;
	}

	public void setPa(double pa) {
		this.pa = pa;
	}

	public boolean isFlock() {
		return flock;
	}

	public void setFlock(boolean flock) {
		this.flock = flock;
	}

	public double getPf() {
		return pf;
	}

	public void setPf(double pf) {
		this.pf = pf;
	}

	public Environment(long seed) {
		super(seed);
		// TODO Auto-generated constructor stub
	}
	
	public void makeAgents() {
		if(n > gridWidth * gridHeight) {
			System.out.println("Too many agents for the space.");
			return;
		}
		for(int i = 0; i<n;i++) {
			int x = random.nextInt(gridWidth);
			int y = random.nextInt(gridHeight);
			int dirx = random.nextInt(3)-1;
			int diry = random.nextInt(3)-1;
			if(this.oneAgentperCell) {
				Bag b = sparseSpace.getObjectsAtLocation(x, y);
				while(b != null) {
					x = random.nextInt(gridWidth);
					y = random.nextInt(gridHeight);
					b = sparseSpace.getObjectsAtLocation(x, y);
				}
			}
			Agent a = new Agent(x,y,dirx,diry);
			schedule.scheduleRepeating(a);
			sparseSpace.setObjectLocation(a, x, y);
		}
		
	}
	
	public void start() {
		super.start();
		spaces = Spaces.SPARSE;
		this.make2DSpace(spaces, gridWidth, gridHeight);
		makeAgents();
	}

}
